package bgu.spl.net.api.bidi;

public class LogoutMessage implements Message{
    public LogoutMessage() {
    }
}
