package bgu.spl.net.api.bidi;

public class UserlistMessage implements Message{
    public UserlistMessage() {
    }
}
